<?PHP
include('config.php');
//variables
$action="";
$id="";
$sem = "";
$year = "";
$cgpa= "";
$faculty = "";
$university = "";
$national = "";
$international = "";
$result = "";
//this block is called when button Submit is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 //values for add or edit
 $sem = $_POST["sem"];
 $year = $_POST["year"];
 $cgpa = trim($_POST["cgpa"]);
 $faculty = trim($_POST["faculty"]);
 $university = trim($_POST["university"]);
 $national = trim($_POST["national"]);
 $international = trim($_POST["international"]);
 $result = trim($_POST["result"]);

 $sql = "INSERT INTO semester (cgpa, faculty, university, national, international, sem, year, result)
 VALUES ('" . $cgpa . "','" . $faculty . "','" . $university . "','" . $national . "','" . $international . "','" . $sem . "', '". $year . "','" . $result . "')";
 $status = insertTo_DBTable($conn, $sql);
 if ($status) {
    echo "New student KPI have successfully added!<br>";
    echo '<a href="my_kpi.php">Back</a>'; 
} else {
    echo '<a href="my_kpi.php">Back</a>';
} 
}

mysqli_close($conn);

function insertTo_DBTable($conn, $sql){
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        echo "Error: " . $sql . " : " . mysqli_error($conn) . "<br>";
        return false;
    }
}
?>