<?php
include("config.php");
$action="";
$id="";
$cgpa = "";
$faculty = "";
$university = "";
$national = "";
$international = "";
$sem = "";
$year = "";
$result = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['cid'];
    $cgpa = trim($_POST['cgpa']);
    $faculty = trim($_POST['faculty']);
    $university = trim($_POST['university']);
    $national = trim($_POST['national']);
    $international = trim($_POST['international']);
    $sem = $_POST['sem'];
    $year = $_POST['year'];
    $result = trim($_POST['result']);

    // Construct the UPDATE query
    $sql = "UPDATE semester SET cgpa = '$cgpa', faculty = '$faculty', university = '$university', national = '$national', international = '$international', sem = '$sem', year = '$year', result = '$result' WHERE ch_id = $id";

    // Execute the update query
    $status = update_DBTable($conn, $sql);

    if ($status) {
        // Success message and redirect back to the page
        echo "Form data updated successfully!<br>";
        echo '<a href="my_kpi.php">Back</a>';
    } else {
        // If there's an error, handle it accordingly
        echo "Error updating record<br>";
        echo '<a href="my_kpi.php">Back</a>';
    }
} else {
    // Redirect back if data is not received properly or if the method is not POST
    header("Location: my_kpi.php");
    exit();
}

// Close the database connection
mysqli_close($conn);

// Function to execute the SQL query
function update_DBTable($conn, $sql) {
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        echo "Error: " . $sql . " : " . mysqli_error($conn) . "<br>";
        return false;
    }
}
?>
