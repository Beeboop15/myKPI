<?php
session_start();
include("config.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,  initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
	<title>profile update</title>
</head>
<body>
  <div class="header">
    <h1>My Study KPI</h1>
	</div>

  <?php
    if(isset($_SESSION["UID"])){
      $userID = $_SESSION["UID"];
      include 'menu.php';
    } else {
      include 'menulogin.php';
    }
   ?>

   <?php
    $sql = "SELECT * FROM user WHERE userID = $userID";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){
      $row = mysqli_fetch_assoc($result);

      // Add checks for each key
      $matricNo = isset($row["matricNo"]) ? $row["matricNo"] : '';
      $userEmail = isset($row["userEmail"]) ? $row["userEmail"] : '';
      $name = isset($row["uname"]) ? $row["uname"] : '';
      $program = isset($row["program"]) ? $row["program"] : '';
      $mentor = isset($row["mentor"]) ? $row["mentor"] : '';
      $motto = isset($row["motto"]) ? $row["motto"] : '';
    }
    ?>

    <div class="column">
      <div class="column-left">
        <img class="image" src="img/photo.jpg">
      </div>
      <div class="column-right">
        <form id="profile" action="profile_update_action.php" method="post">
          <table id="profile_table" width="100%">
          <tr>
            <td width="164">Matric No.</td>
            <td><?=$matricNo?></td>
          </tr>
          <tr>
            <td width="164">Email</td>
            <td><?=$userEmail?></td>
          </tr>
          <tr>
            <td width="164">Name</td>
            <td><input type="text" name="uname" size="20" value="<?=$name?>"></td>
          </tr>                    
          <tr>
            <td width="164">Program</td>
            <td><select size="1" name="program">
            <option value="" <?php echo ($program == '') ? 'selected' : ''; ?> disabled >Select Program</option>  
            <option <?php echo ($program == 'Software Engineering') ? 'selected' : ''; ?>>Software Engineering</option>
            <option <?php echo ($program == 'Network Engineering') ? 'selected' : ''; ?>>Network Engineering</option>
            <option <?php echo ($program == 'Data Science') ? 'selected' : ''; ?>>Data Science</option>
            </select></td>
          </tr>
          <tr>
            <td width="164">Mentor Name</td>
            <td><input type="text" name="mentor" size="20" value="<?=$mentor?>"></td>
          </tr>
          <tr>
            <td colspan="2">
            My Study Motto:                          
            <textarea rows="2" name="motto" style="width:98%"><?=$motto?></textarea>
            </td>
          </tr>
          </table>
        <div style="text-align: right; padding-bottom:5px;">
          <input type="submit" value="Update"> <input type="reset" value="Reset">
        </div>
        </form>
      </div>
    </div>

  <footer class="footer">
    <p>Copyright (c) 2023 - Mohammad Nasiruddin Bin Darwis Awang - BI21110038</p>
  </footer>
</body>
</html>
