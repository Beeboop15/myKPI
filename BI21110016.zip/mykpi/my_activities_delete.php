<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Construct the DELETE query
    $delete_query = "DELETE FROM activity WHERE ch_id = $id";

    if (mysqli_query($conn, $delete_query)) {
        // If deletion is successful, redirect back to the main page
        header("Location: my_activities.php"); // Change 'my_activities.php' to the appropriate page
        exit();
    } else {
        // If there's an error in deletion, display an error message or handle it accordingly
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If no ID is provided or if the request method is not GET, handle the error accordingly
    header("Location: my_activities.php"); // Change 'index.php' to the appropriate page
    exit();
}

// Close the database connection
mysqli_close($conn);
?>