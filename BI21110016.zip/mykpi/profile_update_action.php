<?php
session_start();
include('config.php');

//check if user is logged-in
if(!isset($_SESSION["UID"])){
    header('Location: index.php');
}

//Variables
$uname = "";
$program = "";
$mentor = "";
$motto = "";

//this block is called when button submit is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uname = trim($_POST["uname"]);
    $program = trim($_POST["program"]);
    $mentor = trim($_POST["mentor"]);
    $motto = trim($_POST["motto"]);
    $userID = trim($_SESSION["UID"]);

  // Prepare an SQL statement
  $sql = "UPDATE profile
          SET username = '$uname',
              program = '$program',
              mentor = '$mentor',
              motto = '$motto'
          WHERE userID = $userID";

    echo $sql . "<br>";

    if (mysqli_query($conn, $sql)) {
        echo "Your profile has been updated successfully!<br>";
        echo '<a href="profile.php">Back</a>';
    } else {
        echo "Error: " . $sql . " : " . mysqli_error($conn) . "<br>";
        echo '<a href="javascript:history.back()">Back</a>';
    }
}
// close database connection
mysqli_close($conn);

 ?>
