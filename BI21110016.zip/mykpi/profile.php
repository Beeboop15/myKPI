<?php
session_start();
include("config.php");

//check if logged-in
if(!isset($_SESSION["UID"])){
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,  initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
	<title>BI21110016</title>
</head>
<body>
  <div class="header">
    <h1>My Study KPI</h1>
	</div>

  <?php
    if(isset($_SESSION["UID"])){
      $userID = $_SESSION["UID"];
      include 'menu.php';
    } else {
      include 'menulogin.php';
    }
   ?>

   <?php
     $userID = $_SESSION["UID"];
     $sql = "SELECT * FROM profile WHERE userID = $userID";
     $sql2 = "SELECT matricNo, userEmail FROM user WHERE userID = $userID";
     $result1 = mysqli_query($conn, $sql);
     $result2 = mysqli_query($conn, $sql2);

     if(mysqli_num_rows($result1) > 0){
     $row = mysqli_fetch_assoc($result1);

     // Assign fetched data to variables
     $username = $row["username"] ?? '';
     $program = $row["program"] ?? '';
     $mentor = $row["mentor"] ?? '';
     $motto = $row["motto"] ?? '';
     }
     if(mysqli_num_rows($result2) > 0){
     $row = mysqli_fetch_assoc($result2);

     // Assign fetched data to variables
     $matricNo = $row["matricNo"] ?? '';
     $userEmail = $row["userEmail"] ?? '';
      }
   ?>

   <div class="column">
     <div class="column-left">
      <img class="image" src="img/photo.jpg">
        </div>
        <div class="column-right">
        <div style="text-align: right; padding-bottom:5px;">
        <a href="profile_update.php">Edit</a>
      </div>
                 <table border="1" width="100%">
                  <tr>
                    <td width="164">Matric No.</td>
                    <td><?=$matricNo?></td>
                  </tr>
                  <tr>
                    <td width="164">Email</td>
                    <td><?=$userEmail?></td>
                  </tr>
                   <tr>
                    <td width="164">Name</td>
                    <td><?=$username?></td>
                  </tr>
                  <tr>
                    <td width="164">Program</td>
                    <td><?=$program?></td>
                  </tr>
                  <tr>
                    <td width="164">Mentor Name</td>
                    <td><?=$mentor?></td>
                  </tr>
                </table>
                <p>My Study Motto</p>
                <table border="1" width="100%">
                  <tr>
                    <td>
                           <?php
                             if($motto == ""){
                                 echo "&nbsp;";
                             } else {
                                 echo $motto;
                             }
                             ?>
                             </td>
                            </tr>
                          </table>
                        </div>
                      </div>
       <footer class="footer">
         <p>Copyright (c) 2023 - Jerica Johnny</p>
       </footer>
   </body>
   </html>
