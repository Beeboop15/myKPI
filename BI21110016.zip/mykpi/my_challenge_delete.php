<?php
include('config.php');

if (isset($_GET["id"]) && $_GET["id"] != "") {
    $id = $_GET["id"];

    // Retrieve the column that stores the image filename associated with the record
    $fetch_image_sql = "SELECT img_path FROM challenge WHERE ch_id = $id";
    $fetch_result = mysqli_query($conn, $fetch_image_sql);

    if ($fetch_result) {
        $row = mysqli_fetch_assoc($fetch_result);
        $image_filename = $row['img_path']; // Replace 'image_column_name' with the actual column name

        // Delete the record from the database
        $delete_sql = "DELETE FROM challenge WHERE ch_id = $id";

        if (mysqli_query($conn, $delete_sql)) {
            echo "Record deleted successfully<br>";

            // Delete the associated image file if it exists
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["image_filename"])) {
                $image_filename = $_POST["image_filename"];
            
                $uploads_folder = 'uploads/'; // Path to your uploads folder
                $image_path = $uploads_folder . $image_filename;

                if (file_exists($image_path)) {
                    unlink($image_path); // This deletes the image file
                    echo "Associated image deleted successfully<br>";
                    if (file_exists($image_path)) {
                        if (unlink($image_path)) {
                            echo "Associated image deleted successfully<br>";
                        } else {
                            echo "Unable to delete the image<br>";
                        }
                    } else {
                        echo "Associated image not found<br>";
                    }
                } else {
                    echo "Associated image not found<br>";
                }
            }

            echo '<a href="my_challenge.php">Back</a>';
        } else {
            echo "Error deleting record: " . mysqli_error($conn) . "<br>";
            echo '<a href="my_challenge.php">Back</a>';
        }
    } else {
        echo "Error fetching image filename: " . mysqli_error($conn) . "<br>";
        echo '<a href="my_challenge.php">Back</a>';
    }

    mysqli_close($conn);
} else {
    echo "No record ID provided";
}
?>