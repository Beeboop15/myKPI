<?php
include("config.php");
?>
<!DOCTYPE HTML>
<html lang = "en">
<head>
<title>My Study KPI</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,  initial-scale=1.0">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
function myFunction() {
	var x = document.getElementById("myTopnav");
  	if (x.className === "topnav") {
    	x.className += " responsive";
  	} else {
    	x.className = "topnav";
  	}
}
</script>
</head>
<body>
<header>
<div class="header">
	<h1>My KPI</h1>
</div>
</header>
<?php include 'menu.php';?>

<h2>My KPI Indicator (For each new semester)</h2>
<?php
 $id = "";
 $cgpa =" ";
 $faculty =" ";
 $university =" ";
 $national =" ";
 $international =" ";
 $sem = "";
 $year = "";
 $result = "";
 if(isset($_GET["id"]) && $_GET["id"] != ""){
 $sql = "SELECT * FROM semester WHERE ch_id=" . $_GET["id"];
 //echo $sql . "<br>";
 $result = mysqli_query($conn, $sql);
 
 if (mysqli_num_rows($result) > 0) {
 $row = mysqli_fetch_assoc($result);
 $id = $row["ch_id"];
 $cgpa = $row["cgpa"];
 $faculty = $row["faculty"];
 $university = $row["university"];
 $national = $row["national"];
 $international = $row["international"];
 $sem = $row["sem"];
 $year = $row["year"];
 $result = $row["result"];
 } 
 }
 mysqli_close($conn);
?>
<div style="padding:0 10px;" id="challengeDiv">
 <h3 align="center">Edit KPI Information</h3>
 <p align="center">Required field with mark *</p>
 <form method="POST" action="my_kpi_edit_action.php" id="myForm"
enctype="multipart/form-data">
 <!--hidden value: id to be submitted to action page-->
 <input type="text" id="cid" name="cid" value="<?=$_GET['id']?>" hidden>
 <table border="1" id="myTable"> 
 <tr>
 <td>CGPA *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="cgpa" cols="20" required><?php
 echo $cgpa;?></textarea>
 </td>
 </tr>
 <tr>
 <td>Faculty *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="faculty" cols="20" required><?php
echo $faculty;?></textarea>
 </td>
 </tr>
 <tr>
 <td>University *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="university" cols="20" required><?php
echo $university;?></textarea>
 </td>
 </tr>
 <tr>
 <td>National *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="national" cols="20" required><?php
echo $national;?></textarea>
 </td>
 </tr>
 <tr>
 <td>International *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="international" cols="20" required><?php
echo $international;?></textarea>
 </td>
 </tr>
 <tr>
 <td>Semester *</td>
 <td width="1px">:</td>
 <td>
 <select size="1" name="sem" required> 
 <option value="">&nbsp;</option>
 <?php
if($sem=="1")
 echo '<option value="1" selected>1</option>';
 else
 echo '<option value="1">1</option>';
 if($sem=="2")
 echo '<option value="2" selected>2</option>';
 else
 echo '<option value="2">2</option>';
 ?>
 </select>
 </td>
 </tr>
 <tr>
 <td>Year *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="year" cols="20" required><?php
echo $year;?></textarea>
 </td>
 </tr>
 <tr>
 <td>Result *</td>
 <td>:</td>
 <td>
 <textarea rows="4" name="result" cols="20"><?php echo
$result;?></textarea>
 </td>
 </tr>
 <tr>
 <td colspan="3" align="right">
 <input type="submit" value="Submit" name="B1"> 
 <input type="reset" value="Reset" name="B2"
onclick="resetForm()">
 <input type="button" value="Clear" name="B3"
onclick="clearForm()">
 </td>
 </tr>
 </table>
 </form>
</div>
<p></p>
<footer>
 <p>Copyright (c) 2023 - Jerica Johnny</p>
</footer>
<script>
//for responsive sandwich menu
function myFunction() {
 var x = document.getElementById("myTopnav");
 if (x.className === "topnav") {
 x.className += " responsive";
 } else {
 x.className = "topnav";
}
}
//reset form after modification to a php echo to fields
function resetForm() {
 document.getElementById("myForm").reset();
}
//this clear form to empty the form for new data
function clearForm() {
 var form = document.getElementById("myForm");
 if (form) {
 var inputs = form.getElementsByTagName("input");
 var textareas = form.getElementsByTagName("textarea");
 //clear select
 form.getElementsByTagName("select")[0].selectedIndex=0; 
 
 //clear all inputs
 for (var i = 0; i < inputs.length; i++) {
 if (inputs[i].type !== "button" && inputs[i].type !== "submit" && 
inputs[i].type !== "reset") {
 inputs[i].value = "";
 }
 }
 //clear all textareas
 for (var i = 0; i < textareas.length; i++) {
 textareas[i].value = "";
 }
 } else {
 console.error("Form not found");
 }
}
</script>
</body>
</html>