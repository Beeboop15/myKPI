<?php
include("config.php");
?>
<!DOCTYPE HTML>
<html lang = "en">
<head>
<title>BI21110016</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,  initial-scale=1.0">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
function myFunction() {
	var x = document.getElementById("myTopnav");
  	if (x.className === "topnav") {
    	x.className += " responsive";
  	} else {
    	x.className = "topnav";
  	}
}
</script>
</head>
<body>
<header>
<div class="header">
	<h1>My KPI</h1>
</div>
</header>
<?php include 'menu.php';?>

<h2>My KPI Indicator (For each new semester)</h2>

<div style="padding:0 10px;">

<table border="1" width="100%" id="projectable">
 <tr>
 <th width="2%">No</th>
 <th width="3%">CGPA</th>
 <th width="10%">Faculty</th>
 <th width="10%">University</th>
 <th width="10%">National</th>
 <th width="10%">International</th>
 <th width="1%">Sem</th>
 <th width="3%">Year</th>
 <th width="10%">Result</th>
 <th width="4%">&nbsp;</th>
 </tr>
 <?php
 $sql = "SELECT * FROM semester";
 $result = mysqli_query($conn, $sql);
 if (mysqli_num_rows($result) > 0) {
	// output data of each row
	$numrow=1;
	while($row = mysqli_fetch_assoc($result)) {
		echo "<tr>";
		echo "<td>" . $numrow . "</td><td>". $row["cgpa"] . "</td><td>" . $row["faculty"]. "</td><td>" . $row["university"] ."</td><td>" . $row["national"] . "</td><td>" . $row["international"] . "</td><td>" . $row["sem"] . "</td><td>". $row["year"] . "</td><td>". $row["result"] . "";
		echo '<td> <a href="my_kpi_edit.php?id=' . 
		$row["ch_id"] . '">Edit</a>&nbsp;|&nbsp;';
		echo '<a href="my_kpi_delete.php?id=' . $row["ch_id"] . 
		'" onClick="return confirm(\'Delete?\');">Delete</a> </td>';
		echo "</tr>" . "\n\t\t";
		$numrow++;
	}
} else {
	echo '<tr><td colspan="6">0 results</td></tr>';
} 
mysqli_close($conn); 
?>
</table>
</div>

<div style="padding:0 10px;" id="challengeDiv" >
	<h3 align="center">ADD NEW KPI INFORMATION</h3>
	<p align="center">* Only filled in when the semester have ended *</p>

	<form method="POST" action="my_kpi_action.php" enctype="multipart/form-data" id="myForm">
		<table border="1" id="myTable" >
		<tr>
				<td>CGPA *</td>
				<td>:</td>
				<td>
                    <input type="text" name="cgpa" size="10" required>
				</td>
			</tr>
			<td colspan="6">Student Activity (Name of event participated in each level)</td>
			<tr>
				<td>Faculty *</td>
				<td>:</td>
				<td>
                    <input type="text" name="faculty" size="10" required>
				</td>
			</tr>
            <tr>
				<td>University *</td>
				<td>:</td>
				<td>
                    <input type="text" name="university" size="10" required>
				</td>
			</tr>
			<tr>
				<td>National *</td>
				<td>:</td>
				<td>
                    <input type="text" name="national" size="10" required>
				</td>
			</tr>
			<tr>
				<td>International *</td>
				<td>:</td>
				<td>
                    <input type="text" name="international" size="10" required>
				</td>
			</tr>
			<tr>
				<td>Semester *</td>
				<td width="1px">:</td>
				<td>
					<select size="1" name="sem" required>
                        <option value="">&nbsp;</option>
                        <option value="1">1</option>;
                        <option value="2">2</option>;
					</select>
				</td>
			</tr>
			<tr>
				<td>Year *</td>
				<td>:</td>
				<td>
                    <input type="text" name="year" size="5" required>
				</td>
			</tr>
			<tr>
				<td>Result *</td>
				<td>:</td>
				<td>
                    <input type="text" name="result" size="10" required>
				</td>
			</tr>
			<tr>
				<td colspan="3" align="right">
				<input type="submit" value="Submit" name="B1">
				<input type="reset" value="Reset" name="B2">
				</td>
			</tr>
		</table>
	</form>
</div>
<p></p>
<br>
<footer>
	<p>Copyright (c) 2023 - Jerica Johnny</p>
</footer>
<br>
	</body>
	</html>