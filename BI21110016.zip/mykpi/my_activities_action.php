<?php
include('config.php');

// Variables and configurations...

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch form inputs
    $sem = $_POST["sem"];
    $year = $_POST["year"];
    $activity = trim($_POST["activity"]);
    $date = trim($_POST["date"]);
    $location = trim($_POST["location"]);
    $level = trim($_POST["level"]);
    $points = trim($_POST["points"]);
    $remark = trim($_POST["remark"]);
    $uploadfileName = ''; // Initialize the variable

    // Check if there is an image to be uploaded
    if ($_FILES["fileToUpload"]["error"] == UPLOAD_ERR_OK) {
        $uploadfileName = basename($_FILES["fileToUpload"]["name"]);
        $target_file = "uploads/" . $uploadfileName;
        
        // Check for file existence, size, and allowed formats...
        
        // If upload is OK, move the uploaded file to the destination
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            // File uploaded successfully
        } else {
            // Error while uploading image
            echo "Sorry, there was an error uploading your file.<br>";
            echo '<a href="javascript:history.back()">Back</a>';
            exit(); // Stop further execution
        }
    }

    // Prepare the SQL query based on whether an image was uploaded or not
    $sql = "INSERT INTO activity (sem, year, activity, date, location, level, points, remark, img_path) VALUES ('$sem', '$year', '$activity', '$date', '$location', '$level', '$points', '$remark', '$uploadfileName')";
    
    // Execute the SQL query
    $status = insertTo_DBTable($conn, $sql);

    if ($status) {
        echo "Form data ";
        if ($uploadfileName !== '') {
            echo "and image ";
        }
        echo "saved successfully!<br>";
        echo '<a href="my_activities.php">Back</a>';
    } else {
        echo '<a href="my_activities.php">Back</a>';
    }
}

mysqli_close($conn);

function insertTo_DBTable($conn, $sql){
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        echo "Error: " . $sql . " : " . mysqli_error($conn) . "<br>";
        return false;
    }
}
?>

