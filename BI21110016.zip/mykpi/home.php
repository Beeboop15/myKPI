<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,  initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
	<title>BI21110016</title>
</head>
<body>
  <div class="header">
    <h1>My Study KPI</h1>
	</div>

  <?php
    if(isset($_SESSION["UID"])){
      include 'menu.php';
    } else {
      include 'menulogin.php';
    }
   ?>


  <div class="row">
    <div class="col-login">
    <?php
    if(isset($_SESSION["UID"])){
        ?>
        <div class="imgcontainer">
          <img src="img/photo.jpg" alt="Avatar" class="avatar">
        </div>
      <?php
        echo '<p align="center">Welcome: ' . $_SESSION["userName"] . "<p>";
      }
    else {
      ?>
        <form action="login_action.php" method="post" id="login">
          <div class="container">
            <div class="imgcontainer">
              <img src="img/photo.png" alt="Avatar" class="avatar">
            </div>
            <label for="uname"><b>Username</b></label>
            <input type="text" placeholder="Username" name="userName" required>
            <br>
            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="userPwd" required>
            <button type="submit">Login</button>
            <label> <input type="checkbox" checked="checked" name="remember"> Remember me </label>
            <span class="psw">
              <a href="register.php" style="cursor: pointer;">Register</a>
              <a style="cursor: pointer;">Forgot password?</a>
            </span>
          </div>
        </form>
      <?php
      }
      ?>
      </div>

    <div class="col-news">
      <div id="newsDiv">
        <b>ANNOUCEMENT</b></p>
        <p>We're thrilled to announce the launch of our revamped student website - your ultimate hub for all things academic, fun, and beyond! 🚀 <br>
        <br>
        Discover a world of possibilities at your fingertips:<br>
        📚 Access study resources, tips, and guides to ace your exams. <br>
        🌟 Explore opportunities for internships, scholarships, and career development.<br>
        🎓 Connect with fellow students through forums, clubs, and events.<br>
        📢 Stay updated with campus news, announcements, and important dates.<br>
        <br>
        Join us on this journey of learning, growth, and community. The new student website is here to empower and support you throughout your academic pursuits.
        <br> <br>
        Visit [Website URL] today and embark on an incredible student experience like never before! 💻✨ </p>
        <p><b>NEWS</b></p>
        <p>"Student Union Launches Mental Health Awareness Campaign"<br>
        <br>The Student Union has launched a comprehensive mental health awareness campaign aimed at supporting students' well-being. The initiative, titled "Mind Matters," includes a series of workshops, events, and resources geared towards promoting mental wellness across campus.<br>
          <br>Key highlights of the campaign:<br>
          🧠 Workshops on stress management, mindfulness, and self-care techniques.<br>
          🗣️ Guest speakers and panels discussing mental health in academia.<br>
          🌱 Wellness fairs offering resources for mental health support and guidance.<br>
          🤝 Community-building activities to foster a supportive environment.<br>
          <br>
          This campaign aims to reduce stigma, raise awareness, and provide essential tools for students to prioritize their mental health. Join us in creating a campus where mental well-being is a top priority!
          <br>
          <br>
          <br>
          <br>

      </div>
  </div>
    <footer class="footer">
      <p>Copyright (c) 2023 - Jerica Johnny</p>
    </footer>
</body>
</html>
