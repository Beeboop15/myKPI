<?php
include('config.php');

$action = "";
$id = "";
$sem = "";
$year = "";
$activity = "";
$date = "";
$location = "";
$level = "";
$points = "";
$remark = "";
$img = "";

$target_dir = "uploads/";
$target_file = "";
$uploadOk = 0;
$imageFileType = "";
$uploadfileName = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["cid"];
    $sem = $_POST["sem"];
    $year = $_POST["year"];
    $activity = trim($_POST["activity"]);
    $date = trim($_POST["date"]);
    $location = trim($_POST["location"]);
    $level = trim($_POST["level"]);
    $points = trim($_POST["points"]);
    $remark = trim($_POST["remark"]);

    if (isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["name"] == "") {
        $sql = "UPDATE activity SET sem = $sem, year = '$year', activity = '$activity', date = '$date', location = '$location', level = '$level', points = '$points', remark = '$remark' WHERE ch_id = $id";
        $status = update_DBTable($conn, $sql);

        if ($status) {
            echo "Form data updated successfully!<br>";
            echo '<a href="my_activities.php">Back</a>';
        } else {
            echo "Error updating record<br>";
            echo '<a href="my_activities.php">Back</a>';
        }
    } else {
        $uploadOk = 1;
        $uploadfileName = $_FILES["fileToUpload"]["name"];

        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (file_exists($target_file)) {
            echo "ERROR: Sorry, image file $uploadfileName already exists.<br>";
            $uploadOk = 0;
        }

        if ($_FILES["fileToUpload"]["size"] > 500000) {
            echo "ERROR: Sorry, your file is too large. Try resizing your image.<br>";
            $uploadOk = 0;
        }

        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "ERROR: Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br>";
            $uploadOk = 0;
        }

        if ($uploadOk) {
            $sql = "UPDATE activity SET sem = $sem, year = '$year', activity = '$activity', date = '$date', location = '$location', level = '$level', points = '$points', remark = '$remark', img_path = '$uploadfileName' WHERE ch_id = $id";
            $status = update_DBTable($conn, $sql);

            if ($status && move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                echo "Form data and image updated successfully!<br>";
                echo '<a href="my_activities.php">Back</a>';
            } else {
                echo "Error updating record or uploading image<br>";
                echo '<a href="my_activities.php">Back</a>';
            }
        }
    }
}

mysqli_close($conn);

function update_DBTable($conn, $sql) {
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        echo "Error: " . $sql . " : " . mysqli_error($conn) . "<br>";
        return false;
    }
}
?>
