<?php
// First, include your configuration file to establish a database connection
include("config.php");

if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Get the ID of the KPI entry to be deleted
    $id = $_GET['id'];

    // Construct and execute the DELETE query
    $delete_query = "DELETE FROM semester WHERE ch_id = $id";

    if(mysqli_query($conn, $delete_query)) {
        // If deletion is successful, redirect back to the main page
        header("Location: my_kpi.php"); // Change 'index.php' to the appropriate page
        exit();
    } else {
        // If there's an error in deletion, display an error message
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    // If no ID is provided, redirect back to the main page or handle the error accordingly
    header("Location: my_kpi.php"); // Change 'index.php' to the appropriate page
    exit();
}

// Close the database connection
mysqli_close($conn);
?>
