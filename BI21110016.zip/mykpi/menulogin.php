<?php
echo '<nav class="topnav" id="myTopnav">
  <a href="index.php" class="active">Login</a>
  <a href="register.php">Register</a>
</nav>';
?>
