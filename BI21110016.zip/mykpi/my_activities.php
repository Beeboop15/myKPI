<?php
include("config.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>My Study KPI</title>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>BI21110016</title>
</head>
<body>
<div class="header">
<h1>List of Activities</h1>
</div>

<?php include 'menu.php';?>

<h2>List of My Activities</h2>

<div style="padding:0 10px;">

<table border="1" width="100%" id="projectable">
 <tr>
 <th width="2%">No</th>
 <th width="6%">Sem & Year</th>
 <th width="15%">Activity</th>
 <th width="10%">Date</th>
 <th width="15%">Location</th>
 <th width="12%">Level</th>
 <th width="5%">SDP Points</th>
 <th width="15%">Remark</th>
 <th width="12%">Certificate</th>
 <th width="10%">&nbsp;</th>
 </tr>
 <?php
 $sql = "SELECT * FROM activity";
 $result = mysqli_query($conn, $sql);
 
 if (mysqli_num_rows($result) > 0) {
 // output data of each row
 $numrow=1;
 while($row = mysqli_fetch_assoc($result)) {
 echo "<tr>";
 echo "<td>" . $numrow . "</td><td>". $row["sem"] . " " . $row["year"]. "</td><td>" . $row["activity"] ."</td><td>" . $row["date"] . "</td><td>" . $row["location"]. "</td><td>" . $row["level"]."</td><td>" . $row["points"]. "</td><td>" . $row["remark"] . "</td><td>" . $row["img_path"] . "</td>";
 echo '<td> <a href="my_activities_edit.php?id=' . 
 $row["ch_id"] . '">Edit</a>&nbsp;|&nbsp;';
 echo '<a href="my_activities_delete.php?id=' . $row["ch_id"] . 
'" onClick="return confirm(\'Delete?\');">Delete</a> </td>';
 echo "</tr>" . "\n\t\t";
 $numrow++;
 }
 } else {
 echo '<tr><td colspan="6">0 results</td></tr>';
 } 
 mysqli_close($conn); 
 ?>
 </table>

</div>

<div style="padding:0 10px;" id="challengeDiv">
	<h3 align="center">Add New Activity</h3>
	<p align="center">Required field with mark *</p>

	<form method="POST" action="my_activities_action.php" enctype="multipart/form-data" id="myForm">
		<table border="1" id="myTable">
            <tr>
				<td>Semester *</td>
				<td width="1px">:</td>
				<td>
					<select size="1" name="sem" required>
                        <option value="">&nbsp;</option>
                        <option value="1">1</option>;
                        <option value="2">2</option>;
					</select>
				</td>
			</tr>
			<tr>
				<td>Year *</td>
				<td>:</td>
				<td>
                    <input type="text" name="year" size="5" required>
				</td>
			</tr>
			<tr>
				<td>Name Activity *</td>
				<td>:</td>
				<td>
					<textarea rows="4" name="activity" cols="20" required></textarea>
				</td>
			</tr>
			<tr>
				<td>Date *</td>
				<td>:</td>
				<td>
					<textarea rows="4" name="date" cols="20" required></textarea>
				</td>
			</tr>
			<tr>
				<td>Location *</td>
				<td>:</td>
				<td>
					<textarea rows="4" name="location" cols="20" required></textarea>
				</td>
			</tr>
			<tr>
				<td>Level *</td>
				<td>:</td>
				<td>
					<textarea rows="4" name="level" cols="20" required></textarea>
				</td>
			</tr>
			<tr>
				<td>SDP Points *</td>
				<td>:</td>
				<td>
					<textarea rows="4" name="points" cols="20" required></textarea>
				</td>
			</tr>
			<tr>
				<td>Remark</td>
				<td>:</td>
				<td>
					<textarea rows="4" name="remark" cols="20"></textarea>
				</td>
			</tr>
            <tr>
				<td>Certificate Image</td>
				<td>:</td>
				<td>
                    Max size: 488.28KB<br>
                    <input type="file" name="fileToUpload" id="fileToUpload" accept=".jpg, .jpeg, .png">
				</td>
			</tr>
			<tr>
				<td colspan="3" align="right">
				<input type="submit" value="Submit" name="B1">
				<input type="reset" value="Reset" name="B2">
				</td>
			</tr>
		</table>
	</form>
</div>
<p></p>
<footer>
	<p>Copyright (c) 2023 - Jerica Johnny</p>
</footer>

<script>
//for responsive sandwich menu
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</body>
</html>